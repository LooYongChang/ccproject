<!DOCTYPE html>
<html>
    <head>
        <title>Test</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="text/javascript">
        function shet() {
			window.location.replace("Manageproduct.php");
        }
        window.onload = shet;
        </script>
    </head>
    <body>
    
    </body>
</html>